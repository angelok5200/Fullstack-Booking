package liaskovych.reservation.reservations.availability;

public enum AvailabilityStatus {
    AVAILABLE,
    RESERVED
}
