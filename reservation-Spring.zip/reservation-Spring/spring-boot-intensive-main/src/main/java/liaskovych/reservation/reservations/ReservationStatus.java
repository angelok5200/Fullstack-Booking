package liaskovych.reservation.reservations;

public enum ReservationStatus {
    PENDING,
    APPROVED,
    CANCELLED
}
